﻿$(document).ready(function () {
    //全选
    $("#chooseAll").click(function () {
        $(':checkbox').prop('checked', $(this).is(':checked'));
        checkedLen();
    });

    //部分全选
    $(".weui_check_part").click(function () {
        $(this).closest(".pro_list").find(':checkbox').prop('checked', $(this).is(':checked'));
        checkedLen();
    });

    $(".weui_check").not("#chooseAll").not(".weui_check_part").click(function () {
        if (!$(this).is(':checked')) {//去除全选状态
            $(this).closest(".pro_list").find(".weui_check_part").prop('checked', $(this).is(':checked'));
            $("#chooseAll").prop('checked', $(this).is(':checked'));
        }
        checkedLen();
    });





});


function checkedLen() {//判断当前选中状态
    var length = 0;
    $(".weui_check").each(function () {
        if ($(this).hasClass("weui_check_part") || ($(this).attr("id") == "chooseAll")) {
            return true;
        }else{
            if ($(this).is(':checked')) {
                length++;
            }
        }
    });


    if (length > 0) {
        $(".delete-btn").removeClass("gray-btn");
    } else {
        $(".delete-btn").addClass("gray-btn");
    }
}