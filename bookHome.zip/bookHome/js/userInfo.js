﻿$(document).ready(function () {

    

    //提交
    $("#submitForm").click(function () {
        //查看邮件弹出窗
        $.modal({
            title: "验证邮箱",
            text: "验证邮箱已发送至<br>12345678@ucdavis.edu<br>请在30分钟内点击完成邮箱验证",
            buttons: [
              {
                  text: "立即查收邮件",
                  className: "valideExmail",
                  onClick: function () {
                      //是否已完成验证
                      $.modal({
                          title: "温馨提示",
                          text: "是否已完成验证~",
                          buttons: [
                            {
                                text: "完成",
                                className: "isFinish",
                                onClick: function () {
                                    location.reload();
                                }
                            }
                          ]
                      });
                  }
              }
            ]
        });
    });

    

    //pop层赋值
    $(".weui-popup-container a").click(function () {
        var attrID = $(this).closest(".weui-popup-container").attr("attrID");
        var val = "";
        if (attrID == "3") {//年级
            val = $(this).closest(".weui-popup-container").find("select option:selected").html();
        } else {
            val = $(this).closest(".weui-popup-container").find("input").val();
        }

        if (attrID == "4") {//邮箱
            val ="<span class='noVal'>（未验证）</span>"+ val + "@ucdavis.edu";
        }
        $(".open-popup" + attrID).find(".change_name").html(val);
    });
});