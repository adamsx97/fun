﻿$(document).ready(function () {
    //管理
    $(".manage a").click(function () {
        $(".choose .manage").hide();
        $(".choose .delete").show();
        $(".pro_list .weui_cells_checkbox").show();
    });

    //全选
    $("#chooseAll").click(function () {
        $(':checkbox').prop('checked', $(this).is(':checked'));
    });


    //checkbox选择
    $("input[type=checkbox]").change(function () {
        if ($(this).attr("id") != "chooseAll") {
            if (!$(this).is(':checked')) {
                $('#chooseAll').prop('checked', $(this).is(':checked'));
            }
        }


        var length = $("input[type=checkbox]:checked").length;
        if ($("#chooseAll").is(':checked')) {
            --length;
        }
        if (length == 1) {
            $(".revise-btn").show();
        } else {
            $(".revise-btn").hide();
        }
        
    });

});