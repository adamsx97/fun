/**
 * Created by 苏治政 on 2016/11/27.
 */
$(document).ready(function () {
    var hot_r = $(".hot_recommended").find("li");
    for(i = 0;i < hot_r.length;i++){
        if(i%2 == 1){
            hot_r.eq(i).css({"margin-right":"0"});
        }
    }
    $(".code_input").bind("input propertychange",function () {
        if($(".code_input").val().length >= 1){
            $(".code_ul").removeClass("none");
            $(".search_con[data-info='confirm']").removeClass("none");
            $(".search_con[data-info='cancel']").addClass("none");
        }else if($(".code_input").val().length == 0){
            $(".code_ul").addClass("none");
            $(".search_con[data-info='confirm']").addClass("none");
            $(".search_con[data-info='cancel']").removeClass("none");
        }
    });
    $(".code_input").focus(function () {
        if($(".code_input").val().length >= 1){
            $(".code_ul").removeClass("none");
            $(".search_con[data-info='confirm']").removeClass("none");
            $(".search_con[data-info='cancel']").addClass("none");
        }else if($(".code_input").val().length == 0){
            $(".code_ul").addClass("none");
        }
    });
    $(".code_input").blur(function () {
        setTimeout(function () {
            $(".code_ul").addClass("none");
        },"50");
    });
    $(".code_ul").find("li").click(function () {
        $(".code_input").val($(this).html());
        $(".code_ul").addClass("none");
    });
    $(".num_input").bind("input propertychange",function () {
        if($(".num_input").val().length >= 1){
            $(".num_ul").removeClass("none");
            $(".search_con[data-info='confirm']").removeClass("none");
            $(".search_con[data-info='cancel']").addClass("none");
        }else if($(".num_input").val().length == 0){
            $(".num_ul").addClass("none");
            $(".search_con[data-info='confirm']").addClass("none");
            $(".search_con[data-info='cancel']").removeClass("none");
        }
    });
    $(".num_input").focus(function () {
        if($(".num_input").val().length >= 1){
            $(".num_ul").removeClass("none");
            $(".search_con[data-info='confirm']").removeClass("none");
            $(".search_con[data-info='cancel']").addClass("none");
        }else if($(".num_input").val().length == 0){
            $(".num_ul").addClass("none");
            $(".search_con[data-info='confirm']").addClass("none");
            $(".search_con[data-info='cancel']").removeClass("none");
        }
    });
    $(".num_input").blur(function () {
        setTimeout(function () {
            $(".num_ul").addClass("none");
        },"50");
    });
    $(".num_ul").find("li").click(function () {
        $(".num_input").val($(this).html());
        $(".num_ul").addClass("none");
    });
    if($('.weui_textarea').length > 0){
        $('.weui_textarea').textarea({
            counter: '.weui_textarea_counter', // 计数选择器
            totalCount: 70,                    // 可输入总数
            enableExceed: false,               // 默认false，允许字符超出，超出则提示。
            onInput: function(res) {           // 输入时触发回调
            }
        });
    }
    $(".seller_box div").click(function () {
        $(".seller_box").find("div").find("span").removeClass("seller_active");
        $(this).find("span").addClass("seller_active");
        if($(this).attr('data-info') == 1){
            $(".book_product").removeClass("none");
            $(".supporting").addClass("none");
        }else if($(this).attr('data-info') == 2){
            $(".supporting").removeClass("none");
            $(".book_product").addClass("none");
        }
    });
    $(".book_product_list").find("li").find("div").click(function () {
        $(this).siblings().click();
    });
});
